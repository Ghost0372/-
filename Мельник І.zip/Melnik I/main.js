
function addNumbers() {
    let a = Number(document.getElementById("addFirst").value);
    let b = Number(document.getElementById("addSecond").value);
    let result = a + b;
    document.getElementById("plus").innerHTML = result;
}



function differenceNumbers() {
    let a = Number(document.getElementById("difFirst").value);
    let b = Number(document.getElementById("difSecond").value);
    let result = a - b;
    document.getElementById("minus").innerHTML = result;
}

function multiplyNumbers() {
    let a = Number(document.getElementById("multFirst").value);
    let b = Number(document.getElementById("multSecond").value);
    let result = a * b;
    document.getElementById("mult").innerHTML = result;
}
function divNumbers() {
    let a = Number(document.getElementById("divFirst").value);
    let b = Number(document.getElementById("divSecond").value);
    let result = a / b;
    document.getElementById("div").innerHTML = result;
}
function powNumbers() {
    let a = Number(document.getElementById("powFirst").value);
    let b = Number(document.getElementById("powSecond").value);
    let result = Math.pow(a, b);
    document.getElementById("pow").innerHTML = result;
}
